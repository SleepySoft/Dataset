# Kapok
更好的序列化库，纯c++11开发，header-only，简洁高效。

Kapok---一个更好的序列化/反序列化库

可以很方便的将对象序列化和反序列化，序列化后的格式是标准的json格式。

wiki介绍：https://github.com/qicosmos/Kapok/wiki
社区：http://purecpp.org/